<template>
<div class="bg-overview" v-show="global.islogin">
</div>
</template>

<style>

.bg-overview {
    min-height: 100vh;
    background-image: url('@/svg/overview.svg');
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;

    /* position: relative; */
}
</style>

<script>
export default {
    name: 'overviewView'
}
</script>