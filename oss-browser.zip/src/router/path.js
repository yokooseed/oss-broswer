export default {
    root: '/',

    overview: '/overview',

    login: '/login',

    register: '/register',

    bucketList: '/bucket/list',

    bucketDetail: '/bucket/detail',

    authManage: '/bucket/auth',

    version: '/version',

    setting: '/setting',
}